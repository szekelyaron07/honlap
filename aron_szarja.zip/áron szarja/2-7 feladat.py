import math

# Számok beolvasása és tárolása
szamok = []
szamok_input = input("Adjon meg egy sor számot szóközzel elválasztva: ")
szamok_str = szamok_input.split(" ")

for szam_str in szamok_str:
    szam = float(szam_str)
    szamok.append(szam)

# 2. feladat: Páratlan számok minimuma az 1. sorban
paratlan_szamok = [szam for szam in szamok if szam % 2 == 1]
paratlan_min = min(paratlan_szamok)

print("2. feladat eredménye: ", paratlan_min)

# 3. feladat: Páros számok négyzeteinek összege az 2. sorban
paros_szamok = [szam for szam in szamok if szam % 2 == 0]
paros_negyzet_osszeg = sum([szam ** 2 for szam in paros_szamok])

print("3. feladat eredménye: ", paros_negyzet_osszeg)

# 4. feladat: A 3. sorban szereplő 15 legkisebb szám maximuma
sor_3 = szamok[30:45]
sor_3_kisebb = sorted(sor_3)[:15]
sor_3_max = max(sor_3_kisebb)

print("4. feladat eredménye: ", sor_3_max)

# 5. feladat: A 4. sorban szereplő négyzetszámok szorzatának nagyságrendje
sor_4_negyzetszamok = [szam ** 2 for szam in szamok[45:60]]
sor_4_szorzat = math.prod(sor_4_negyzetszamok)
sor_4_nagysagrend = 10 ** math.floor(math.log10(sor_4_szorzat))

print("5. feladat eredménye: ", sor_4_nagysagrend)

# 6. feladat: Az 5. sorban szereplő számok összege
sor_5 = szamok[60:75]
sor_5_osszeg = sum(sor_5)

print("6. feladat eredménye: ", sor_5_osszeg)

# 7. feladat: Az összes számra vonatkozó 17 legnagyobb szám számtani középének kiszámítása
szamtani_kozepek = []
szamok_rendezett = sorted(szamok, reverse=True)

for i in range(0, len(szamok), 17):
    szamok_resz = szamok_rendezett[i:i+17]
    szamtani_kozep = sum(szamok_resz) / len(szamok_resz)
    szamtani_kozepek.append(szamtani_kozep)

print("7. feladat eredménye: ", szamtani_kozepek)