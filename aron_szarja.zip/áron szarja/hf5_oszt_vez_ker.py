import math

# Számok beolvasása és tárolása
szamok = []
szamok_input = input("Adjon meg egy sor számot szóközzel elválasztva: ")
szamok_str = szamok_input.split(" ")

for szam_str in szamok_str:
    szam = float(szam_str)
    szamok.append(szam)

# Rendezés növekvő sorrendbe
szamok.sort()

# Kerekítés két tizedesjegyre és nagyságrend meghatározása
kerekitett_szamok = []
nagy_szamok = []

for szam in szamok:
    kerekitett = round(szam, 2)
    kerekitett_szamok.append(kerekitett)
    
    nagy_szam = 10 ** math.floor(math.log10(szam))
    nagy_szamok.append(nagy_szam)

# Eredmények kiírása
print("Kerekített számok: ", kerekitett_szamok)
print("Nagyságrendek: ", nagy_szamok)